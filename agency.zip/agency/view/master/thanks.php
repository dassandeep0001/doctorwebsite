<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Thanks update us with this fields on whatsapp we create eportfolio with in a week. </h1>
						<h1 class="page-subhead-line">Whatsapp all  <a href="?action=field">details</a> with 10 pics to +919001092208. If you already done then Ignore this.</h1>
						 
						 
						 
				
                    </div>
                </div>
             
                               
                           
                        </div>
                            </div>

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
		<script>
function copyClipboard() {
  var elm = document.getElementById("divClipboard");
  // for Internet Explorer

  if(document.body.createTextRange) {
    var range = document.body.createTextRange();
    range.moveToElementText(elm);
    range.select();
    document.execCommand("Copy");
    alert("Copied div content to clipboard");
  }
  else if(window.getSelection) {
    // other browsers

    var selection = window.getSelection();
    var range = document.createRange();
    range.selectNodeContents(elm);
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand("Copy");
    alert("Copied div content to clipboard");
  }
}
</script>
		
<?php 

include('view/common/footer.php');
?>		