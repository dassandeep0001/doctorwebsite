<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Field require to add models </h1>
						<h1 class="page-subhead-line">Whatsapp all details with 10 pics to +919001092208</h1>
						 <button class="btn btn-primary col-md-12" type="button" onclick="copyClipboard()" >Copy below information</button>
						 <div id="divClipboard" >
                        <h1 class="page-subhead-line"  >
						Name : shanaya<br>
Age : 32<br>
Date Of Birth: 1-8-1986<br>
Gender : female<br>
Marital Status: single<br>
Place : Chandigarh <br>
Nationality : indian<br>
Height : 5’3”<br>
Weight :53<br>
Hips :34<br>
Breast : 34<br>
Waist : 28<br>
Skin Tone : fair<br>
Eye Color : black<br>
Hair Color : black<br>
Shoe Size : 5<br>
Profession: singer<br>
Education:b.tech<br>
Dress Comfortable With:  western yes<br>
 timings : any<br>
Open for out station shoots : yes<br>
Open for out country shoots : yes<br>
Semi nude:no<br>
Nude:no<br>
Passport : yes<br>
Skills : strong communicatie skills,adopt to all situations <br>
Hobbies : traveling, parting,music ,dancing,trying new things , net surfing, reading<br>
Languages Known : English, Hindi, punjabi<br>
Contact Number : <br>
Email Id:<br>
Address:<br>
Experiences:one year in singing<br>
Interested in acting:yes<br>
Ethnic wear: yes<br>
Western wear: yes<br>
Bikini Shoots: no<br>
Lingerie shoot:no<br>
Swim suit:no<br>
Calendar Shoot:yes<br>
Music album: yes<br>
Indian wear:yes<br>
Western: yes<br>
Skirt: yes<br>
Bikini:no<br>
Shorts:yes<br>
Any allergies:no<br>
cosmetics: good brand.. MAC,Lakmé,elly18, good brand<br>
Details of experience :<br>
fresher in the field modeling and acting.. <br>
1 year in music album singing<br>
						
						
						</h1>
					</div>	

                    </div>
                </div>
             
                               
                           
                        </div>
                            </div>

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
		<script>
function copyClipboard() {
  var elm = document.getElementById("divClipboard");
  // for Internet Explorer

  if(document.body.createTextRange) {
    var range = document.body.createTextRange();
    range.moveToElementText(elm);
    range.select();
    document.execCommand("Copy");
    alert("Copied div content to clipboard");
  }
  else if(window.getSelection) {
    // other browsers

    var selection = window.getSelection();
    var range = document.createRange();
    range.selectNodeContents(elm);
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand("Copy");
    alert("Copied div content to clipboard");
  }
}
</script>
		
			
<?php 

include('view/common/footer.php');
?>