
<?php
		// Database host
	 define("DB_HOST", "localhost");
	// Database user
	define("DB_USER", "root");
	// Database password
	define("DB_PASSWORD","");
	// Database name
	define("DB_NAME", "model");
	
	 
	//website URL
	define("BASEURL", "http://localhost/model");
	define("BASEURLFORIMAGES", "http://localhost/ajay/admin/");

 
	//Website Name
	define("SITENAME", "ICSG");
 	define("SENDMAILFROM", "info@greatBasinNationalPark.com");
	
	//Email address to send mail
	 
					 
 
?>
